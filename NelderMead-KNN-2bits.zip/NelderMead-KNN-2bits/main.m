clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 1000000;

SUdistances = [707;707;707;707;1581;1581;1581;1581];  %in metres          
           
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

data = load('data_testSize1000000.mat');   %10 million gives the 'out of memory' error
trainingEnergyVectors = data.trainingEnergyVectors;
testEnergyVectors = data.testEnergyVectors;
actualPUpresence_training = data.actualPUpresence_training;
actualPUpresence_test = data.actualPUpresence_test;

[ pfa_exact, pd_exact, probOfError_exact ] = findErrorProb1( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );

thresholds = [64;192;320];   

options_1 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_1, errorProb_1, output_1] = fminsearch(@findErrorProb2_1_2bits, thresholds, options_1);
save('optimisedThresholds_1.mat', 'optimisedThresholds_1');

options_2 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_2, errorProb_2, output_2] = fminsearch(@findErrorProb2_2_2bits, thresholds, options_2);
save('optimisedThresholds_2.mat', 'optimisedThresholds_2');

options_3 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_3, errorProb_3, output_3] = fminsearch(@findErrorProb2_3_2bits, thresholds, options_3);
save('optimisedThresholds_3.mat', 'optimisedThresholds_3');

options_4 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_4, errorProb_4, output_4] = fminsearch(@findErrorProb2_4_2bits, thresholds, options_4);
save('optimisedThresholds_4.mat', 'optimisedThresholds_4');

options_5 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_5, errorProb_5, output_5] = fminsearch(@findErrorProb2_5_2bits, thresholds, options_5);
save('optimisedThresholds_5.mat', 'optimisedThresholds_5');

options_6 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_6, errorProb_6, output_6] = fminsearch(@findErrorProb2_6_2bits, thresholds, options_6);
save('optimisedThresholds_6.mat', 'optimisedThresholds_6');

options_7 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_7, errorProb_7, output_7] = fminsearch(@findErrorProb2_7_2bits, thresholds, options_7);
save('optimisedThresholds_7.mat', 'optimisedThresholds_7');

options_8 = optimset('PlotFcns',@optimplotfval);
[optimisedThresholds_8, errorProb_8, output_8] = fminsearch(@findErrorProb2_8_2bits, thresholds, options_8);

%Having all the findErrorProb2_1_2bits, findErrorProb2_2_2bits, etc.
%functions may seem redundant but it is necessary to have all of them
%because 'fminsearch' can only accept a function with one argument
%%
originalTheta = [64;192;320];
testDataSize = 100000;

for i = 1:100
    
    i
    
    [trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
    [testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

    trainingEnergyVectors_2_unoptimised = quantise_2bits(trainingEnergyVectors, originalTheta);
    testEnergyVectors_2_unoptimised = quantise_2bits(testEnergyVectors, originalTheta);  
    [ pfa_unoptimised(i), pd_unoptimised(i), probOfError_unoptimised(i) ] = findErrorProb1( trainingEnergyVectors_2_unoptimised, testEnergyVectors_2_unoptimised, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     

    trainingEnergyVectors_2_optimised = zeros(trainingDataSize, length(SUdistances));
    trainingEnergyVectors_2_optimised(:, 1) = quantise_2bits(trainingEnergyVectors(:, 1), optimisedThresholds_1);
    trainingEnergyVectors_2_optimised(:, 2) = quantise_2bits(trainingEnergyVectors(:, 2), optimisedThresholds_2);
    trainingEnergyVectors_2_optimised(:, 3) = quantise_2bits(trainingEnergyVectors(:, 3), optimisedThresholds_3);
    trainingEnergyVectors_2_optimised(:, 4) = quantise_2bits(trainingEnergyVectors(:, 4), optimisedThresholds_4);
    trainingEnergyVectors_2_optimised(:, 5) = quantise_2bits(trainingEnergyVectors(:, 5), optimisedThresholds_5);
    trainingEnergyVectors_2_optimised(:, 6) = quantise_2bits(trainingEnergyVectors(:, 6), optimisedThresholds_6);
    trainingEnergyVectors_2_optimised(:, 7) = quantise_2bits(trainingEnergyVectors(:, 7), optimisedThresholds_7);
    trainingEnergyVectors_2_optimised(:, 8) = quantise_2bits(trainingEnergyVectors(:, 8), optimisedThresholds_8);       
    testEnergyVectors_2_optimised = zeros(testDataSize, length(SUdistances));
    testEnergyVectors_2_optimised(:, 1) = quantise_2bits(testEnergyVectors(:, 1), optimisedThresholds_1);
    testEnergyVectors_2_optimised(:, 2) = quantise_2bits(testEnergyVectors(:, 2), optimisedThresholds_2);
    testEnergyVectors_2_optimised(:, 3) = quantise_2bits(testEnergyVectors(:, 3), optimisedThresholds_3);
    testEnergyVectors_2_optimised(:, 4) = quantise_2bits(testEnergyVectors(:, 4), optimisedThresholds_4);
    testEnergyVectors_2_optimised(:, 5) = quantise_2bits(testEnergyVectors(:, 5), optimisedThresholds_5);
    testEnergyVectors_2_optimised(:, 6) = quantise_2bits(testEnergyVectors(:, 6), optimisedThresholds_6);
    testEnergyVectors_2_optimised(:, 7) = quantise_2bits(testEnergyVectors(:, 7), optimisedThresholds_7);
    testEnergyVectors_2_optimised(:, 8) = quantise_2bits(testEnergyVectors(:, 8), optimisedThresholds_8);   
    [ pfa_optimised(i), pd_optimised(i), probOfError_optimised(i) ] = findErrorProb1( trainingEnergyVectors_2_optimised, testEnergyVectors_2_optimised, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     
 
    trainingEnergyVectors = round((trainingEnergyVectors - 865.84) / 2);    
    testEnergyVectors = round((testEnergyVectors - 865.84) / 2);
    [ pfa_exactTest(i), pd_exactTest(i), probOfError_exactTest(i) ] = findErrorProb1( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     
   
end  

avg_probOfError_exactTest = mean(probOfError_exactTest);
avg_probOfError_optimised = mean(probOfError_optimised);
avg_probOfError_unoptimised = mean(probOfError_unoptimised);
