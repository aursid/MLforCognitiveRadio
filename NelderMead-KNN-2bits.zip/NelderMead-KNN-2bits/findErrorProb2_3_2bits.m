function [ errorProb ] = findErrorProb2_3_2bits( thresholds )

    data = load('data_testSize1000000.mat');   %10 million gives the 'out of memory' error
    trainingEnergyVectors = data.trainingEnergyVectors;
    testEnergyVectors = data.testEnergyVectors;
    actualPUpresence_training = data.actualPUpresence_training;
    actualPUpresence_test = data.actualPUpresence_test;
    trainingDataSize = 500;
    testDataSize = 1000000;
    k = 25;
    SUdistances = [707;707;707;707;1581;1581;1581;1581];  %in metres 

    theta = [64;192;320];
    trainingEnergyVectors_2 = quantise_2bits(trainingEnergyVectors, theta);
    testEnergyVectors_2 = quantise_2bits(testEnergyVectors, theta);    
    
    optimThresh = load('optimisedThresholds_1.mat');      
    trainingEnergyVectors_2(:, 1) = quantise_2bits(trainingEnergyVectors(:, 1), optimThresh.optimisedThresholds_1);
    testEnergyVectors_2(:, 1) = quantise_2bits(testEnergyVectors(:, 1), optimThresh.optimisedThresholds_1); 
    
    optimThresh = load('optimisedThresholds_2.mat');      
    trainingEnergyVectors_2(:, 2) = quantise_2bits(trainingEnergyVectors(:, 2), optimThresh.optimisedThresholds_2);
    testEnergyVectors_2(:, 2) = quantise_2bits(testEnergyVectors(:, 2), optimThresh.optimisedThresholds_2);     
    
    trainingEnergyVectors_2(:, 3) = quantise_2bits(trainingEnergyVectors(:, 3), thresholds);
    testEnergyVectors_2(:, 3) = quantise_2bits(testEnergyVectors(:, 3), thresholds);  
    
    [ pfa, pd, errorProb ] = findErrorProb1(trainingEnergyVectors_2, testEnergyVectors_2, trainingDataSize, testDataSize, k, actualPUpresence_training, SUdistances, actualPUpresence_test );

end

