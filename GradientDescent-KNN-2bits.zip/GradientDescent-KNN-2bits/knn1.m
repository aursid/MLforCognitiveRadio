function [ ratio ] = knn1(channelAvail, weightedTrainingVectors, weightedTestVectors, trainingEnergyVectors, trainingDataSize, testDataSize, k, actualPUpresence_training, SUdistances, distanceType )

    Mdl = fitcknn(weightedTrainingVectors', actualPUpresence_training', 'NumNeighbors', 25);
    [label, score, cost] = predict(Mdl, weightedTestVectors');
    ratio = score(:, 1);
    
end

