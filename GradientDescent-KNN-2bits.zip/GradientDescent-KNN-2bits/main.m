clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 1000000;

SUdistances = [707;707;707;707;1581;1581;1581;1581];  %in metres          
           
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

data = load('data_testSize1000000.mat');
trainingEnergyVectors = data.trainingEnergyVectors;
testEnergyVectors = data.testEnergyVectors;
trainingEnergyVectors_2bits = data.trainingEnergyVectors_2bits;
testEnergyVectors_2bits = data.testEnergyVectors_2bits;
actualPUpresence_training = data.actualPUpresence_training;
actualPUpresence_test = data.actualPUpresence_test;

[ pfa_exact, pd_exact, probOfError_exact ] = findErrorProb1( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );
[ pfa_originalTheta, pd_originalTheta, probOfError_originalTheta ] = findErrorProb1( trainingEnergyVectors_2bits, testEnergyVectors_2bits, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );

theta = [64;192;320];

trainingEnergyVectors_2 = quantise_2bits(trainingEnergyVectors, theta);
testEnergyVectors_2 = quantise_2bits(testEnergyVectors, theta);

finalThetas = zeros(length(theta), length(SUdistances));
learningRate = 10000;
constant = 0.01;
maxIterations = 20;

for l = 1:length(SUdistances)
    finalThetas(:, l) = theta;
end

previousProb = probOfError_originalTheta;
for i = 1:length(SUdistances)
    
    theta = [64;192;320];   
    for k = 1:maxIterations      
        
        for j = 1:length(theta)        
            
            i*10000 + j*1000 + k
        
            thetaPlusConstant = theta;
            thetaPlusConstant(j) = thetaPlusConstant(j) + constant;
            trainingEnergyVectors_2(:, i) = quantise_2bits(trainingEnergyVectors(:, i), thetaPlusConstant);
            testEnergyVectors_2(:, i) = quantise_2bits(testEnergyVectors(:, i), thetaPlusConstant);
            [ pfa_tpc(i, j, k), pd_tpc(i, j, k), probOfError_tpc(i, j, k) ] = findErrorProb1( trainingEnergyVectors_2, testEnergyVectors_2, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );

            thetaMinusConstant = theta;
            thetaMinusConstant(j) = thetaMinusConstant(j) - constant;
            trainingEnergyVectors_2(:, i) = quantise_2bits(trainingEnergyVectors(:, i), thetaMinusConstant);
            testEnergyVectors_2(:, i) = quantise_2bits(testEnergyVectors(:, i), thetaMinusConstant);
            [ pfa_tmc(i, j, k), pd_tmc(i, j, k), probOfError_tmc(i, j, k) ] = findErrorProb1( trainingEnergyVectors_2, testEnergyVectors_2, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );

            gradient(i, j, k) = (probOfError_tpc(i, j, k) - probOfError_tmc(i, j, k)) / (2 * constant);
                   
        end  
        
        newTheta = theta - learningRate * gradient(i, :, k)';
        trainingEnergyVectors_2(:, i) = quantise_2bits(trainingEnergyVectors(:, i), newTheta);
        testEnergyVectors_2(:, i) = quantise_2bits(testEnergyVectors(:, i), newTheta);
        [ pfa_t(i, j, k), pd_t(i, j, k), probOfError_t(i, j, k) ] = findErrorProb1( trainingEnergyVectors_2, testEnergyVectors_2, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );
        
        if(probOfError_t(i, j, k) > previousProb)
            learningRate = learningRate / 2; 
            disp('learningRate: ')
            learningRate
        else
            theta = newTheta;
            previousProb = probOfError_t(i, j, k);
            learningRate = 10000;
        end
        
    end
    
    finalThetas(:, i) = theta;
    trainingEnergyVectors_2(:, i) = quantise_2bits(trainingEnergyVectors(:, i), theta);
    testEnergyVectors_2(:, i) = quantise_2bits(testEnergyVectors(:, i), theta); 
    learningRate = 10000;
    
end    

%%
originalTheta = [64;192;320];
testDataSize = 100000;
for i = 1:100
    
    i
    
    [trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
    [testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

    trainingEnergyVectors_2_unoptimised = quantise_2bits(trainingEnergyVectors, originalTheta);
    testEnergyVectors_2_unoptimised = quantise_2bits(testEnergyVectors, originalTheta);  
    [ pfa_unoptimised(i), pd_unoptimised(i), probOfError_unoptimised(i) ] = findErrorProb1( trainingEnergyVectors_2_unoptimised, testEnergyVectors_2_unoptimised, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     

    trainingEnergyVectors_2_optimised = zeros(trainingDataSize, length(SUdistances));
    for j = 1:length(SUdistances)
        trainingEnergyVectors_2_optimised(:, j) = quantise_2bits(trainingEnergyVectors(:, j), finalThetas(:, j));
    end   
    testEnergyVectors_2_optimised = zeros(testDataSize, length(SUdistances));
    for j = 1:length(SUdistances)
        testEnergyVectors_2_optimised(:, j) = quantise_2bits(testEnergyVectors(:, j), finalThetas(:, j));
    end       
    [ pfa_optimised(i), pd_optimised(i), probOfError_optimised(i) ] = findErrorProb1( trainingEnergyVectors_2_optimised, testEnergyVectors_2_optimised, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     
  
    [ pfa_exactTest(i), pd_exactTest(i), probOfError_exactTest(i) ] = findErrorProb1( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, actualPUpresence_test );                     
   
end  

avg_probOfError_exactTest = mean(probOfError_exactTest);
avg_probOfError_optimised = mean(probOfError_optimised);
avg_probOfError_unoptimised = mean(probOfError_unoptimised);
