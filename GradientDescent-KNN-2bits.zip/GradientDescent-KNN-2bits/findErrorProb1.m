function [ pfa, pd, probOfError ] = findErrorProb1( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, k, actualPUpresence_training, SUdistances, actualPUpresence_test )

    channelAvail = actualPUpresence_training;
    channelAvail(channelAvail == 0) = -1;
    for o = 1:length(SUdistances)
        nthComp = trainingEnergyVectors(:, o);
        [X,Y,T,AUC(o)] = perfcurve(channelAvail', nthComp, 1);
    end
    %find the distance of every training vector from the test vector
    weightedTrainingVectors = diag(AUC') * trainingEnergyVectors';
    weightedTestVectors = diag(AUC') * testEnergyVectors'; 
    ratio_euclidean = knn1(channelAvail, weightedTrainingVectors, weightedTestVectors, trainingEnergyVectors, trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');

    predictedState = ratio_euclidean';
    predictedState(predictedState >= 0.5) = -1;
    predictedState(predictedState ~= -1) = -2;
    predictedState(predictedState == -1) = 0;
    predictedState(predictedState == -2) = 1;
    pfa = sum(predictedState == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    pd = sum(predictedState == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    probOfError = pfa*0.5 + (1-pd)*0.5;

end

