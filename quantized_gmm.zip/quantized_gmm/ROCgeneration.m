clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 5000;

SUdistances = [707;707;707;707;1581;1581;1581;1581;1581;1581;1581;1581;
               2121;2121;2121;2121;2550;2550;2550;2550;2915;2915;2915;
               2915;3536];  %in metres
                     
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

[trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
[testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

trainingEnergyVectors_8 = round((trainingEnergyVectors - 865.84) / 2);
testEnergyVectors_8 = round((testEnergyVectors - 865.84) / 2);

trainingEnergyVectors_4 = round((trainingEnergyVectors - 865.84) / 32);
testEnergyVectors_4 = round((testEnergyVectors - 865.84) / 32);

trainingEnergyVectors_3 = round((trainingEnergyVectors - 865.84) / 64);
testEnergyVectors_3 = round((testEnergyVectors - 865.84) / 64);

trainingEnergyVectors_2 = round((trainingEnergyVectors - 865.84) / 128);
testEnergyVectors_2 = round((testEnergyVectors - 865.84) / 128);

trainingEnergyVectors_1 = round((trainingEnergyVectors - 865.84) / 256);
testEnergyVectors_1 = round((testEnergyVectors - 865.84) / 256);

trainingEnergyVectors(trainingEnergyVectors < 0) = 0;
trainingEnergyVectors_8(trainingEnergyVectors_8 < 0) = 0;
trainingEnergyVectors_4(trainingEnergyVectors_4 < 0) = 0;
trainingEnergyVectors_3(trainingEnergyVectors_3 < 0) = 0;
trainingEnergyVectors_2(trainingEnergyVectors_2 < 0) = 0;
trainingEnergyVectors_1(trainingEnergyVectors_1 < 0) = 0;

testEnergyVectors(testEnergyVectors < 0) = 0;
testEnergyVectors_8(testEnergyVectors_8 < 0) = 0;
testEnergyVectors_4(testEnergyVectors_4 < 0) = 0;
testEnergyVectors_3(testEnergyVectors_3 < 0) = 0;
testEnergyVectors_2(testEnergyVectors_2 < 0) = 0;
testEnergyVectors_1(testEnergyVectors_1 < 0) = 0;

[vk, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance] = gmm(100, trainingEnergyVectors, noOfSignalSamples, trainingDataSize, SUdistances);
[vk_8, cluster1mean_8, cluster2mean_8, cluster1covariance_8, cluster2covariance_8] = gmm(8, trainingEnergyVectors_8, noOfSignalSamples, trainingDataSize, SUdistances);
[vk_4, cluster1mean_4, cluster2mean_4, cluster1covariance_4, cluster2covariance_4] = gmm(4, trainingEnergyVectors_4, noOfSignalSamples, trainingDataSize, SUdistances);
[vk_3, cluster1mean_3, cluster2mean_3, cluster1covariance_3, cluster2covariance_3] = gmm(3, trainingEnergyVectors_3, noOfSignalSamples, trainingDataSize, SUdistances);
[vk_2, cluster1mean_2, cluster2mean_2, cluster1covariance_2, cluster2covariance_2] = gmm(2, trainingEnergyVectors_2, noOfSignalSamples, trainingDataSize, SUdistances);
[vk_1, cluster1mean_1, cluster2mean_1, cluster1covariance_1, cluster2covariance_1] = gmm(1, trainingEnergyVectors_1, noOfSignalSamples, trainingDataSize, SUdistances);

[cluster1mean2dim, cluster2mean2dim, cluster1sigma3dim, cluster2sigma3dim] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance);
[cluster1mean2dim_8, cluster2mean2dim_8, cluster1sigma3dim_8, cluster2sigma3dim_8] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean_8, cluster2mean_8, cluster1covariance_8, cluster2covariance_8);
[cluster1mean2dim_4, cluster2mean2dim_4, cluster1sigma3dim_4, cluster2sigma3dim_4] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean_4, cluster2mean_4, cluster1covariance_4, cluster2covariance_4);
[cluster1mean2dim_3, cluster2mean2dim_3, cluster1sigma3dim_3, cluster2sigma3dim_3] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean_3, cluster2mean_3, cluster1covariance_3, cluster2covariance_3);
[cluster1mean2dim_2, cluster2mean2dim_2, cluster1sigma3dim_2, cluster2sigma3dim_2] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean_2, cluster2mean_2, cluster1covariance_2, cluster2covariance_2);
[cluster1mean2dim_1, cluster2mean2dim_1, cluster1sigma3dim_1, cluster2sigma3dim_1] = extendingMeanAndCov(SUdistances, testDataSize, cluster1mean_1, cluster2mean_1, cluster1covariance_1, cluster2covariance_1);

gamma = linspace(0, 10, 1000);
for n = 1:numel(gamma)    

    [probOfFalseAlarm_GMM(n), probOfDetection_GMM(n)] = probsForROC(vk, testEnergyVectors, cluster1mean2dim, cluster1sigma3dim, cluster2mean2dim, cluster2sigma3dim, gamma(n), actualPUpresence_test);
    [probOfFalseAlarm_GMM_8(n), probOfDetection_GMM_8(n)] = probsForROC(vk_8, testEnergyVectors_8, cluster1mean2dim_8, cluster1sigma3dim_8, cluster2mean2dim_8, cluster2sigma3dim_8, gamma(n), actualPUpresence_test);
    [probOfFalseAlarm_GMM_4(n), probOfDetection_GMM_4(n)] = probsForROC(vk_4, testEnergyVectors_4, cluster1mean2dim_4, cluster1sigma3dim_4, cluster2mean2dim_4, cluster2sigma3dim_4, gamma(n), actualPUpresence_test);
    [probOfFalseAlarm_GMM_3(n), probOfDetection_GMM_3(n)] = probsForROC(vk_3, testEnergyVectors_3, cluster1mean2dim_3, cluster1sigma3dim_3, cluster2mean2dim_3, cluster2sigma3dim_3, gamma(n), actualPUpresence_test);
    [probOfFalseAlarm_GMM_2(n), probOfDetection_GMM_2(n)] = probsForROC(vk_2, testEnergyVectors_2, cluster1mean2dim_2, cluster1sigma3dim_2, cluster2mean2dim_2, cluster2sigma3dim_2, gamma(n), actualPUpresence_test);
    [probOfFalseAlarm_GMM_1(n), probOfDetection_GMM_1(n)] = probsForROC(vk_1, testEnergyVectors_1, cluster1mean2dim_1, cluster1sigma3dim_1, cluster2mean2dim_1, cluster2sigma3dim_1, gamma(n), actualPUpresence_test);
    %sometimes lines 72 and 73, i.e., when the number of bits is <= 2, give
    %the following error "Error using mvnpdf: SIGMA must be a square,
    %symmetric, positive definite matrix."
end

figure;
%%
plot(probOfFalseAlarm_GMM, probOfDetection_GMM, 'b')
hold on
plot(probOfFalseAlarm_GMM_8, probOfDetection_GMM_8, 'r')
plot(probOfFalseAlarm_GMM_4, probOfDetection_GMM_4, 'g')
plot(probOfFalseAlarm_GMM_3, probOfDetection_GMM_3, 'c')
plot(probOfFalseAlarm_GMM_2, probOfDetection_GMM_2, 'm')
plot(probOfFalseAlarm_GMM_1, probOfDetection_GMM_1, 'k')

legend('Exact values', 'n = 8', 'n = 4', 'n = 3', 'n = 2', 'n = 1')
xlabel('Probability of false alarm')
ylabel('Probability of detection')
title('GMM with n bits')


