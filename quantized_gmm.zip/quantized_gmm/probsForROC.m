function [ probOfFalseAlarm_GMM, probOfDetection_GMM ] = probsForROC( vk, testEnergyVectors, cluster1mean2dim, cluster1sigma3dim, cluster2mean2dim, cluster2sigma3dim, gamma, actualPUpresence_test )

    first = vk(1) * mvnpdf(testEnergyVectors, cluster1mean2dim, cluster1sigma3dim);
    second = vk(2) * mvnpdf(testEnergyVectors, cluster2mean2dim, cluster2sigma3dim);
    stat = log(first + second) - log(first);
    stat(stat >= gamma) = 1;
    stat(stat ~= 1) = 0;    
    PredictedStateGMM = stat;   
    probOfFalseAlarm_GMM = sum(PredictedStateGMM' == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_GMM = sum(PredictedStateGMM' == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    
end

