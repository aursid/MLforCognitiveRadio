function [ cluster1mean2dim, cluster2mean2dim, cluster1sigma3dim, cluster2sigma3dim ] = extendingMeanAndCov( SUdistances, testDataSize, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance )

    cluster1sigma3dim = zeros(length(SUdistances), length(SUdistances), testDataSize);
    cluster1mean2dim = zeros(testDataSize, length(SUdistances));
    a = 1:1:25;
    for i = 1:length(a)
        cluster1sigma3dim(a(i), a(i), :) = cluster1covariance(a(i), a(i));
        cluster1mean2dim(:, a(i)) = cluster1mean(a(i));
        cluster2sigma3dim(a(i), a(i), :) = cluster2covariance(a(i), a(i));
        cluster2mean2dim(:, a(i)) = cluster2mean(a(i));        
    end

end

