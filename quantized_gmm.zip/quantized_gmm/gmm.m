function [ vk, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance ] = gmm( bits, trainingEnergyVectors, noOfSignalSamples, trainingDataSize, SUdistances )

    TrainingDataGMM = trainingEnergyVectors';

    cluster1mean = 2*noOfSignalSamples * ones(length(SUdistances), 1);
    cluster1covariance = 4*noOfSignalSamples * eye(length(SUdistances));
    
    cluster2mean = TrainingDataGMM(:, trainingDataSize);
    convert2diag = 2000 + rand(length(SUdistances), 1);
    cluster2covariance = diag(convert2diag);
    
    if(bits == 8)
        cluster1mean = round((cluster1mean - 865.84) / 2);
        cluster1covariance = cluster1covariance / (2^2);
        cluster2covariance = cluster2covariance / (2^2);
    elseif(bits == 4)
        cluster1mean = round((cluster1mean - 865.84) / 32);
        cluster1covariance = cluster1covariance / (32^2);
        cluster2covariance = cluster2covariance / (32^2);    
    elseif(bits == 3)
        cluster1mean = round((cluster1mean - 865.84) / 64);
        cluster1covariance = cluster1covariance / (64^2);
        cluster2covariance = cluster2covariance / (64^2);    
    elseif(bits == 2)
        cluster1mean = round((cluster1mean - 865.84) / 128);
        cluster1covariance = cluster1covariance / (128^2);
        cluster2covariance = cluster2covariance / (128^2); 
    elseif(bits == 1)
        cluster1mean = round((cluster1mean - 865.84) / 256);
        cluster1covariance = cluster1covariance / (256^2);
        cluster2covariance = cluster2covariance / (256^2);       
    end     
    
    cluster1mean(cluster1mean < 0) = 0;
    %if bits == 100, it means no quantisation. This is my own convention.
        
    vk = [0.5; 0.5];    
    for k = 1:1000
        
        for a = 1:trainingDataSize
            phi1(a) = mvnpdf(TrainingDataGMM(:, a), cluster1mean, cluster1covariance);
            phi2(a) = mvnpdf(TrainingDataGMM(:, a), cluster2mean, cluster2covariance);
        end
        
        u1 = (vk(1) * phi1) ./ (vk(1) * phi1 + vk(2) * phi2);
        u2 = (vk(2) * phi2) ./ (vk(1) * phi1 + vk(2) * phi2);

        vk(1) = mean(u1);
        vk(2) = mean(u2);

        cluster2mean = sum(diag(u2') * TrainingDataGMM')/sum(u2);
        cluster2mean = cluster2mean';

        total = zeros(length(SUdistances), length(SUdistances));
        for b = 1:trainingDataSize
            total = total + u2(b) * (diag(TrainingDataGMM(:, b) - cluster2mean))^2;
        end
        cluster2covariance = total/sum(u2);

    end

end

