clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 5000;

SUdistances = [707;707;707;707;1581;1581;1581;1581;1581;1581;1581;1581;
               2121;2121;2121;2121;2550;2550;2550;2550;2915;2915;2915;
               2915;3536];  %in metres          
           
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

[trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
[testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

trainingEnergyVectors_8bits = round((trainingEnergyVectors - 865.84) / 2);
testEnergyVectors_8bits = round((testEnergyVectors - 865.84) / 2);

trainingEnergyVectors_4bits = round((trainingEnergyVectors - 865.84) / 32);
testEnergyVectors_4bits = round((testEnergyVectors - 865.84) / 32);

trainingEnergyVectors_3bits = round((trainingEnergyVectors - 865.84) / 64);
testEnergyVectors_3bits = round((testEnergyVectors - 865.84) / 64);

trainingEnergyVectors_2bits = round((trainingEnergyVectors - 865.84) / 128);
testEnergyVectors_2bits = round((testEnergyVectors - 865.84) / 128);

trainingEnergyVectors_1bits = round((trainingEnergyVectors - 865.84) / 256);
testEnergyVectors_1bits = round((testEnergyVectors - 865.84) / 256);

trainingEnergyVectors(trainingEnergyVectors < 0) = 0;
trainingEnergyVectors_8bits(trainingEnergyVectors_8bits < 0) = 0;
trainingEnergyVectors_4bits(trainingEnergyVectors_4bits < 0) = 0;
trainingEnergyVectors_3bits(trainingEnergyVectors_3bits < 0) = 0;
trainingEnergyVectors_2bits(trainingEnergyVectors_2bits < 0) = 0;
trainingEnergyVectors_1bits(trainingEnergyVectors_1bits < 0) = 0;

testEnergyVectors(testEnergyVectors < 0) = 0;
testEnergyVectors_8bits(testEnergyVectors_8bits < 0) = 0;
testEnergyVectors_4bits(testEnergyVectors_4bits < 0) = 0;
testEnergyVectors_3bits(testEnergyVectors_3bits < 0) = 0;
testEnergyVectors_2bits(testEnergyVectors_2bits < 0) = 0;
testEnergyVectors_1bits(testEnergyVectors_1bits < 0) = 0;

ratio_euclidean = knn(trainingEnergyVectors, testEnergyVectors', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_euclidean_8bits = knn(trainingEnergyVectors_8bits, testEnergyVectors_8bits', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_euclidean_4bits = knn(trainingEnergyVectors_4bits, testEnergyVectors_4bits', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_euclidean_3bits = knn(trainingEnergyVectors_3bits, testEnergyVectors_3bits', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_euclidean_2bits = knn(trainingEnergyVectors_2bits, testEnergyVectors_2bits', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_euclidean_1bits = knn(trainingEnergyVectors_1bits, testEnergyVectors_1bits', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');

beta = linspace(0, 20, 1000);
for n = 1:numel(beta)
    
    for m = 1:testDataSize      

        if (ratio_euclidean(m) >= beta(n))
            PredictedStateKNN_euclidean(m) = 0;
        else
            PredictedStateKNN_euclidean(m) = 1;
        end
        
        if (ratio_euclidean_8bits(m) >= beta(n))
            PredictedStateKNN_euclidean_8bits(m) = 0;
        else
            PredictedStateKNN_euclidean_8bits(m) = 1;
        end  
        
        if (ratio_euclidean_4bits(m) >= beta(n))
            PredictedStateKNN_euclidean_4bits(m) = 0;
        else
            PredictedStateKNN_euclidean_4bits(m) = 1;
        end    
        
        if (ratio_euclidean_3bits(m) >= beta(n))
            PredictedStateKNN_euclidean_3bits(m) = 0;
        else
            PredictedStateKNN_euclidean_3bits(m) = 1;
        end 
        
        if (ratio_euclidean_2bits(m) >= beta(n))
            PredictedStateKNN_euclidean_2bits(m) = 0;
        else
            PredictedStateKNN_euclidean_2bits(m) = 1;
        end  
        
        if (ratio_euclidean_1bits(m) >= beta(n))
            PredictedStateKNN_euclidean_1bits(m) = 0;
        else
            PredictedStateKNN_euclidean_1bits(m) = 1;
        end          
        
    end

    probOfFalseAlarm_KNN_euclidean(n) = sum(PredictedStateKNN_euclidean == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean(n) = sum(PredictedStateKNN_euclidean == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);

    probOfFalseAlarm_KNN_euclidean_8bits(n) = sum(PredictedStateKNN_euclidean_8bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean_8bits(n) = sum(PredictedStateKNN_euclidean_8bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);

    probOfFalseAlarm_KNN_euclidean_4bits(n) = sum(PredictedStateKNN_euclidean_4bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean_4bits(n) = sum(PredictedStateKNN_euclidean_4bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    
    probOfFalseAlarm_KNN_euclidean_3bits(n) = sum(PredictedStateKNN_euclidean_3bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean_3bits(n) = sum(PredictedStateKNN_euclidean_3bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);

    probOfFalseAlarm_KNN_euclidean_2bits(n) = sum(PredictedStateKNN_euclidean_2bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean_2bits(n) = sum(PredictedStateKNN_euclidean_2bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);

    probOfFalseAlarm_KNN_euclidean_1bits(n) = sum(PredictedStateKNN_euclidean_1bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean_1bits(n) = sum(PredictedStateKNN_euclidean_1bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
     
end

figure;

plot(probOfFalseAlarm_KNN_euclidean, probOfDetection_KNN_euclidean, 'b')
hold on
plot(probOfFalseAlarm_KNN_euclidean_8bits, probOfDetection_KNN_euclidean_8bits, 'r')
plot(probOfFalseAlarm_KNN_euclidean_4bits, probOfDetection_KNN_euclidean_4bits, 'g')
plot(probOfFalseAlarm_KNN_euclidean_3bits, probOfDetection_KNN_euclidean_3bits, 'c')
plot(probOfFalseAlarm_KNN_euclidean_2bits, probOfDetection_KNN_euclidean_2bits, 'm')
plot(probOfFalseAlarm_KNN_euclidean_1bits, probOfDetection_KNN_euclidean_1bits, 'k')

legend('Exact values', 'n = 8', 'n = 4', 'n = 3', 'n = 2', 'n = 1')
xlabel('Probability of false alarm')
ylabel('Probability of detection')
title('KNN-Euclidean with n bits')


