function [ energyVectors_2 ] = quantise_2bits( energyVectors, thresholds )

    energyVectors_2 = energyVectors - 865.84;
    energyVectors_2(energyVectors_2 < thresholds(1)) = 0;
    energyVectors_2(energyVectors_2 >= thresholds(1) & energyVectors_2 < thresholds(2)) = 1;
    energyVectors_2(energyVectors_2 >= thresholds(2) & energyVectors_2 < thresholds(3)) = 2;
    energyVectors_2(energyVectors_2 >= thresholds(3)) = 3;

end

