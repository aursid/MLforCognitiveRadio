clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 5000;

SUdistances = [707;707;707;707;1581;1581;1581;1581;1581;1581;1581;1581;
               2121;2121;2121;2121;2550;2550;2550;2550;2915;2915;2915;
               2915;3536];  %in metres
                   
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

[trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
[testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

trainingEnergyVectors_8bits = round((trainingEnergyVectors - 865.84) / 2);
testEnergyVectors_8bits = round((testEnergyVectors - 865.84) / 2);

trainingEnergyVectors_4bits = round((trainingEnergyVectors - 865.84) / 32);
testEnergyVectors_4bits = round((testEnergyVectors - 865.84) / 32);

trainingEnergyVectors_3bits = round((trainingEnergyVectors - 865.84) / 64);
testEnergyVectors_3bits = round((testEnergyVectors - 865.84) / 64);

trainingEnergyVectors_2bits = round((trainingEnergyVectors - 865.84) / 128);
testEnergyVectors_2bits = round((testEnergyVectors - 865.84) / 128);

trainingEnergyVectors_1bits = round((trainingEnergyVectors - 865.84) / 256);
testEnergyVectors_1bits = round((testEnergyVectors - 865.84) / 256);

trainingEnergyVectors(trainingEnergyVectors < 0) = 0;
trainingEnergyVectors_8bits(trainingEnergyVectors_8bits < 0) = 0;
trainingEnergyVectors_4bits(trainingEnergyVectors_4bits < 0) = 0;
trainingEnergyVectors_3bits(trainingEnergyVectors_3bits < 0) = 0;
trainingEnergyVectors_2bits(trainingEnergyVectors_2bits < 0) = 0;
trainingEnergyVectors_1bits(trainingEnergyVectors_1bits < 0) = 0;

testEnergyVectors(testEnergyVectors < 0) = 0;
testEnergyVectors_8bits(testEnergyVectors_8bits < 0) = 0;
testEnergyVectors_4bits(testEnergyVectors_4bits < 0) = 0;
testEnergyVectors_3bits(testEnergyVectors_3bits < 0) = 0;
testEnergyVectors_2bits(testEnergyVectors_2bits < 0) = 0;
testEnergyVectors_1bits(testEnergyVectors_1bits < 0) = 0;

[probOfFalseAlarm_SVM_linear, probOfDetection_SVM_linear] = svm(trainingEnergyVectors, actualPUpresence_training, testEnergyVectors', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_linear_8bits, probOfDetection_SVM_linear_8bits] = svm(trainingEnergyVectors_8bits, actualPUpresence_training, testEnergyVectors_8bits', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_linear_4bits, probOfDetection_SVM_linear_4bits] = svm(trainingEnergyVectors_4bits, actualPUpresence_training, testEnergyVectors_4bits', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_linear_3bits, probOfDetection_SVM_linear_3bits] = svm(trainingEnergyVectors_3bits, actualPUpresence_training, testEnergyVectors_3bits', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_linear_2bits, probOfDetection_SVM_linear_2bits] = svm(trainingEnergyVectors_2bits, actualPUpresence_training, testEnergyVectors_2bits', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_linear_1bits, probOfDetection_SVM_linear_1bits] = svm(trainingEnergyVectors_1bits, actualPUpresence_training, testEnergyVectors_1bits', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);

figure;

plot(probOfFalseAlarm_SVM_linear, probOfDetection_SVM_linear, 'b')
hold on
plot(probOfFalseAlarm_SVM_linear_8bits, probOfDetection_SVM_linear_8bits, 'r')  
plot(probOfFalseAlarm_SVM_linear_4bits, probOfDetection_SVM_linear_4bits, 'g')  
plot(probOfFalseAlarm_SVM_linear_3bits, probOfDetection_SVM_linear_3bits, 'c')  
plot(probOfFalseAlarm_SVM_linear_2bits, probOfDetection_SVM_linear_2bits, 'm')  
plot(probOfFalseAlarm_SVM_linear_1bits, probOfDetection_SVM_linear_1bits, 'k')  

legend('Exact values', 'n = 8', 'n = 4', 'n = 3', 'n = 2', 'n = 1')
xlabel('Probability of false alarm')
ylabel('Probability of detection')
title('SVM-Linear with n bits')


