clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 5000;

SUdistances = [707;707;707;707;1581;1581;1581;1581;1581;1581;1581;1581;
               2121;2121;2121;2121;2550;2550;2550;2550;2915;2915;2915;
               2915;3536];  %in metres          
           
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

[trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
[testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

trainingEnergyVectors_8bits = round((trainingEnergyVectors - 865.84) / 2);
testEnergyVectors_8bits = round((testEnergyVectors - 865.84) / 2);

trainingEnergyVectors_4bits = round((trainingEnergyVectors - 865.84) / 32);
testEnergyVectors_4bits = round((testEnergyVectors - 865.84) / 32);

trainingEnergyVectors_3bits = round((trainingEnergyVectors - 865.84) / 64);
testEnergyVectors_3bits = round((testEnergyVectors - 865.84) / 64);

trainingEnergyVectors_2bits = round((trainingEnergyVectors - 865.84) / 128);
testEnergyVectors_2bits = round((testEnergyVectors - 865.84) / 128);

trainingEnergyVectors_1bits = round((trainingEnergyVectors - 865.84) / 256);
testEnergyVectors_1bits = round((testEnergyVectors - 865.84) / 256);

trainingEnergyVectors(trainingEnergyVectors < 0) = 0;
trainingEnergyVectors_8bits(trainingEnergyVectors_8bits < 0) = 0;
trainingEnergyVectors_4bits(trainingEnergyVectors_4bits < 0) = 0;
trainingEnergyVectors_3bits(trainingEnergyVectors_3bits < 0) = 0;
trainingEnergyVectors_2bits(trainingEnergyVectors_2bits < 0) = 0;
trainingEnergyVectors_1bits(trainingEnergyVectors_1bits < 0) = 0;

testEnergyVectors(testEnergyVectors < 0) = 0;
testEnergyVectors_8bits(testEnergyVectors_8bits < 0) = 0;
testEnergyVectors_4bits(testEnergyVectors_4bits < 0) = 0;
testEnergyVectors_3bits(testEnergyVectors_3bits < 0) = 0;
testEnergyVectors_2bits(testEnergyVectors_2bits < 0) = 0;
testEnergyVectors_1bits(testEnergyVectors_1bits < 0) = 0;

[centroid_PUnotPresent, centroid_PUpresent] = kMeansClustering(100, trainingEnergyVectors, noOfSignalSamples, SUdistances, trainingDataSize);
[centroid_PUnotPresent_8bits, centroid_PUpresent_8bits] = kMeansClustering(8, trainingEnergyVectors_8bits, noOfSignalSamples, SUdistances, trainingDataSize);
[centroid_PUnotPresent_4bits, centroid_PUpresent_4bits] = kMeansClustering(4, trainingEnergyVectors_4bits, noOfSignalSamples, SUdistances, trainingDataSize);
[centroid_PUnotPresent_3bits, centroid_PUpresent_3bits] = kMeansClustering(3, trainingEnergyVectors_3bits, noOfSignalSamples, SUdistances, trainingDataSize);
[centroid_PUnotPresent_2bits, centroid_PUpresent_2bits] = kMeansClustering(2, trainingEnergyVectors_2bits, noOfSignalSamples, SUdistances, trainingDataSize);
[centroid_PUnotPresent_1bits, centroid_PUpresent_1bits] = kMeansClustering(1, trainingEnergyVectors_1bits, noOfSignalSamples, SUdistances, trainingDataSize);

alpha = linspace(0.5, 2, 1000);
for n = 1:numel(alpha)
    
    for m = 1:testDataSize
      
        D1_1(m) = pdist([centroid_PUnotPresent'; testEnergyVectors(m,:)]);
        D1_2(m) = pdist([centroid_PUpresent'; testEnergyVectors(m,:)]);

        if (D1_1(m)/D1_2(m) >= alpha(n))
            PredictedState_KmeansClustering(m) = 1;
        else
            PredictedState_KmeansClustering(m) = 0;
        end
        
        D1_1_8bits(m) = pdist([centroid_PUnotPresent_8bits'; testEnergyVectors_8bits(m,:)]);
        D1_2_8bits(m) = pdist([centroid_PUpresent_8bits'; testEnergyVectors_8bits(m,:)]);

        if (D1_1_8bits(m)/D1_2_8bits(m) >= alpha(n))
            PredictedState_KmeansClustering_8bits(m) = 1;
        else
            PredictedState_KmeansClustering_8bits(m) = 0;
        end
        
        D1_1_4bits(m) = pdist([centroid_PUnotPresent_4bits'; testEnergyVectors_4bits(m,:)]);
        D1_2_4bits(m) = pdist([centroid_PUpresent_4bits'; testEnergyVectors_4bits(m,:)]);

        if (D1_1_4bits(m)/D1_2_4bits(m) >= alpha(n))
            PredictedState_KmeansClustering_4bits(m) = 1;
        else
            PredictedState_KmeansClustering_4bits(m) = 0;
        end 
        
        D1_1_3bits(m) = pdist([centroid_PUnotPresent_3bits'; testEnergyVectors_3bits(m,:)]);
        D1_2_3bits(m) = pdist([centroid_PUpresent_3bits'; testEnergyVectors_3bits(m,:)]);

        if (D1_1_3bits(m)/D1_2_3bits(m) >= alpha(n))
            PredictedState_KmeansClustering_3bits(m) = 1;
        else
            PredictedState_KmeansClustering_3bits(m) = 0;
        end             
        
        D1_1_2bits(m) = pdist([centroid_PUnotPresent_2bits'; testEnergyVectors_2bits(m,:)]);
        D1_2_2bits(m) = pdist([centroid_PUpresent_2bits'; testEnergyVectors_2bits(m,:)]);

        if (D1_1_2bits(m)/D1_2_2bits(m) >= alpha(n))
            PredictedState_KmeansClustering_2bits(m) = 1;
        else
            PredictedState_KmeansClustering_2bits(m) = 0;
        end  
        
        D1_1_1bits(m) = pdist([centroid_PUnotPresent_1bits'; testEnergyVectors_1bits(m,:)]);
        D1_2_1bits(m) = pdist([centroid_PUpresent_1bits'; testEnergyVectors_1bits(m,:)]);

        if (D1_1_1bits(m)/D1_2_1bits(m) >= alpha(n))
            PredictedState_KmeansClustering_1bits(m) = 1;
        else
            PredictedState_KmeansClustering_1bits(m) = 0;
        end          

    end

    probOfFalseAlarm_KmeansClustering(n) = sum(PredictedState_KmeansClustering == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering(n) = sum(PredictedState_KmeansClustering == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    
    probOfFalseAlarm_KmeansClustering_8bits(n) = sum(PredictedState_KmeansClustering_8bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering_8bits(n) = sum(PredictedState_KmeansClustering_8bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);    

    probOfFalseAlarm_KmeansClustering_4bits(n) = sum(PredictedState_KmeansClustering_4bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering_4bits(n) = sum(PredictedState_KmeansClustering_4bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);        

    probOfFalseAlarm_KmeansClustering_3bits(n) = sum(PredictedState_KmeansClustering_3bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering_3bits(n) = sum(PredictedState_KmeansClustering_3bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);                
    
    probOfFalseAlarm_KmeansClustering_2bits(n) = sum(PredictedState_KmeansClustering_2bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering_2bits(n) = sum(PredictedState_KmeansClustering_2bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);            

    probOfFalseAlarm_KmeansClustering_1bits(n) = sum(PredictedState_KmeansClustering_1bits == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering_1bits(n) = sum(PredictedState_KmeansClustering_1bits == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);            

end

figure;

plot(probOfFalseAlarm_KmeansClustering, probOfDetection_KmeansClustering, 'b')
hold on
plot(probOfFalseAlarm_KmeansClustering_8bits, probOfDetection_KmeansClustering_8bits, 'r')
plot(probOfFalseAlarm_KmeansClustering_4bits, probOfDetection_KmeansClustering_4bits, 'g')
plot(probOfFalseAlarm_KmeansClustering_3bits, probOfDetection_KmeansClustering_3bits, 'c')
plot(probOfFalseAlarm_KmeansClustering_2bits, probOfDetection_KmeansClustering_2bits, 'm')
plot(probOfFalseAlarm_KmeansClustering_1bits, probOfDetection_KmeansClustering_1bits, 'k')

legend('Exact values', 'n = 8', 'n = 4', 'n = 3', 'n = 2', 'n = 1')
xlabel('Probability of false alarm')
ylabel('Probability of detection')
title('K-means Clustering with n bits')


