function [ energyVectors, actualPUpresence ] = dataGeneration( tau, noOfSignalSamples, PUpower, bandwidth, dataSize, SUdistances, noiseSpectralDensity_mw )

    mu_noPU = 2 * noOfSignalSamples * ones(length(SUdistances), 1);
    mu_PUpresent = 2 * noOfSignalSamples * ones(length(SUdistances), 1) + 2 * tau * (SUdistances .^ -4) * PUpower / noiseSpectralDensity_mw;
    sigma_noPU = diag(4 * noOfSignalSamples * ones(length(SUdistances), 1));
    sigma_PUpresent = diag(4 * noOfSignalSamples * ones(length(SUdistances), 1) + 8 * tau * (SUdistances .^ -4) * PUpower / noiseSpectralDensity_mw);

    noPUvectors = mvnrnd(mu_noPU, sigma_noPU, dataSize/2);
    PUpresentVectors = mvnrnd(mu_PUpresent, sigma_PUpresent, dataSize/2);
    actualPUpresence = [zeros(dataSize/2, 1); ones(dataSize/2, 1)];
    
    combined = [actualPUpresence, [noPUvectors; PUpresentVectors]];
    
    combined_shuffled = combined(randperm(dataSize), :);
    
    actualPUpresence = combined_shuffled(:, 1)';
    
    combined_shuffled(:, 1) = []; 
    energyVectors = combined_shuffled;  

end

