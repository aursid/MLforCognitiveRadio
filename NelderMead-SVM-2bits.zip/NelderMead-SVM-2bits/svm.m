function [ probOfFalseAlarm, probOfDetection, probOfError ] = svm( trainingEnergyVectors, actualPUpresence_training, testEnergyVectors, actualPUpresence_test, kernelFunction, trainingDataSize, testDataSize )

    rng(1);
    SVMModel = fitcsvm(trainingEnergyVectors, actualPUpresence_training', 'Standardize', true, 'KernelFunction', kernelFunction, 'KernelScale', 'auto');

    beta = SVMModel.Beta;
    scale = SVMModel.KernelParameters.Scale;
    
    testEnergyVectors = testEnergyVectors';
    avg = -1 * mean(testEnergyVectors/scale * beta);    
    bias_threshold = 0.9579;
    bias_threshold = avg * bias_threshold;

    prod = (testEnergyVectors/scale) * beta;
    
    PredictedStates = sign(prod + bias_threshold); 
    PredictedStates(PredictedStates == -1) = 0;

    probOfFalseAlarm = sum(PredictedStates' == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection = sum(PredictedStates' == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    probOfError = 0.5*probOfFalseAlarm + 0.5*(1 - probOfDetection);

end

