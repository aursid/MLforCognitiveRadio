function [ errorProb ] = findErrorProb2_5_2bits( thresholds )

    data = load('data_testSize1000000.mat');   %10 million gives the 'out of memory' error
    trainingEnergyVectors = data.trainingEnergyVectors;
    testEnergyVectors = data.testEnergyVectors;
    actualPUpresence_training = data.actualPUpresence_training;
    actualPUpresence_test = data.actualPUpresence_test;
    trainingDataSize = 500;
    testDataSize = 1000000;
    k = 25;
    SUdistances = [707;707;707;707;1581;1581;1581;1581];  %in metres 

    theta = [64;192;320];
    trainingEnergyVectors_2 = quantise_2bits(trainingEnergyVectors, theta);
    testEnergyVectors_2 = quantise_2bits(testEnergyVectors, theta);    
    
    optimThresh = load('optimisedThresholds_1.mat');      
    trainingEnergyVectors_2(:, 1) = quantise_2bits(trainingEnergyVectors(:, 1), optimThresh.optimisedThresholds_1);
    testEnergyVectors_2(:, 1) = quantise_2bits(testEnergyVectors(:, 1), optimThresh.optimisedThresholds_1); 
    
    optimThresh = load('optimisedThresholds_2.mat');      
    trainingEnergyVectors_2(:, 2) = quantise_2bits(trainingEnergyVectors(:, 2), optimThresh.optimisedThresholds_2);
    testEnergyVectors_2(:, 2) = quantise_2bits(testEnergyVectors(:, 2), optimThresh.optimisedThresholds_2);    
    
    optimThresh = load('optimisedThresholds_3.mat');      
    trainingEnergyVectors_2(:, 3) = quantise_2bits(trainingEnergyVectors(:, 3), optimThresh.optimisedThresholds_3);
    testEnergyVectors_2(:, 3) = quantise_2bits(testEnergyVectors(:, 3), optimThresh.optimisedThresholds_3);
    
    optimThresh = load('optimisedThresholds_4.mat');      
    trainingEnergyVectors_2(:, 4) = quantise_2bits(trainingEnergyVectors(:, 4), optimThresh.optimisedThresholds_4);
    testEnergyVectors_2(:, 4) = quantise_2bits(testEnergyVectors(:, 4), optimThresh.optimisedThresholds_4);    
    
    trainingEnergyVectors_2(:, 5) = quantise_2bits(trainingEnergyVectors(:, 5), thresholds);
    testEnergyVectors_2(:, 5) = quantise_2bits(testEnergyVectors(:, 5), thresholds);    
    
    [ pfa, pd, errorProb ] = svm(trainingEnergyVectors_2, actualPUpresence_training, testEnergyVectors_2', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);

end

