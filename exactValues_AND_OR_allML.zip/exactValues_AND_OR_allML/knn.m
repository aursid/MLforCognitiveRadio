function [ ratio ] = knn( trainingEnergyVectors, testEnergyVectors, trainingDataSize, testDataSize, k, actualPUpresence_training, SUdistances, distanceType )

    channelAvail = actualPUpresence_training;
    channelAvail(channelAvail == 0) = -1;

    for o = 1:length(SUdistances)
        nthComp = trainingEnergyVectors(:, o);
        [X,Y,T,AUC(o)] = perfcurve(channelAvail', nthComp, 1);
    end

    %the following part of the function can be replaced with the built-in
    %MATLAB functions 'fitcknn' and 'predict'. This has been done in the
    %'NelderMead-KNN-2bits' and 'GradientDescent-KNN-2bits' folders    
    
    %find the distance of every training vector from the test vector
    weightedTrainingVectors = diag(AUC') * trainingEnergyVectors';
    weightedTestVectors = diag(AUC') * testEnergyVectors;
    combined = [weightedTestVectors'; weightedTrainingVectors'];
    distances = pdist(combined, distanceType);

    %now arrange training vectors in ascending order
    c = 1;    
    firstIndex = testDataSize;
    lastIndex = firstIndex + trainingDataSize - 1;
    for i = 1:testDataSize
        appendDistances = [distances(firstIndex:lastIndex)' channelAvail' trainingEnergyVectors];
        appendDistances = sortrows(appendDistances, 1);

        %now find number of -1 and 1 in top k rows
        labels = appendDistances(:, 2);
        labels = labels(1:k);
        minusOnes = sum(labels(:) == -1);
        plusOnes = sum(labels(:) == 1);
        ratio(i) = minusOnes/plusOnes;
        
        c = c + 1;
        firstIndex = lastIndex + 1 + testDataSize - c;
        lastIndex = firstIndex + trainingDataSize - 1;        
    end

end

