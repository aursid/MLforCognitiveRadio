function [ probOfFalseAlarm, probOfDetection ] = svm_poly( trainingEnergyVectors, actualPUpresence_training, testEnergyVectors, actualPUpresence_test, kernelFunction, trainingDataSize, testDataSize )

    rng(1);
    SVMModel = fitcsvm(trainingEnergyVectors, actualPUpresence_training', 'Standardize', true, 'KernelFunction', 'polynomial', 'PolynomialOrder', 3);

    alpha = zeros(length(SVMModel.IsSupportVector), 1);
    j = 1;
    for i = 1:length(SVMModel.IsSupportVector)
        if(SVMModel.IsSupportVector(i) == 1)
            alpha(i) = SVMModel.Alpha(j);
            j = j + 1;
        end
    end
    
    RESULT = (1 + trainingEnergyVectors * testEnergyVectors) .^ 3;
    prod = (sum(diag(alpha) * diag(actualPUpresence_training) * RESULT))';
    avg = -1 * mean(prod);
    
    bias_threshold = -3:0.0001:3;
    bias_threshold = avg * bias_threshold;      
    
    for x = 1:length(bias_threshold)    
        PredictedStates = sign(prod + bias_threshold(x)); 
        PredictedStates(PredictedStates == -1) = 0;

        probOfFalseAlarm(x) = sum(PredictedStates' == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
        probOfDetection(x) = sum(PredictedStates' == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    end

end

