function [ centroid_PUnotPresent, centroid_PUpresent ] = kMeansClustering(trainingEnergyVectors, noOfSignalSamples, SUdistances, trainingDataSize )
    %Help fror this function was taken from the thesis "Spectrum Sensing
    %for Cognitive Radio using Diversity Combining and Machine Learning
    %Techniques" by Deep Chandra Kandpal of LNMIIT, India
    
    TrainingData = trainingEnergyVectors';

    centroid_PUnotPresent = 2*noOfSignalSamples * ones(length(SUdistances), 1);
    centroid_PUpresent = TrainingData(:,round(rand*trainingDataSize));

    K = 2;  %number of clusters
    
    for i = 1:1000
        
        index1 = 1;
        index2 = 1;
        clear Cluster1 Cluster2;
        
        for m = 1:trainingDataSize
            
            D_1 = pdist([centroid_PUnotPresent'; TrainingData(:,m)']);
            D_2 = pdist([centroid_PUpresent'; TrainingData(:,m)']);

            if D_1 <= D_2
                Cluster1(:,index1) = TrainingData(:,m);
                index1 = index1 + 1;
            else
                Cluster2(:,index2) = TrainingData(:,m);
                index2 = index2 + 1;
            end
            
        end
        
        C_new2 = mean(Cluster2,2);

        if centroid_PUpresent == C_new2
            break
        else
            centroid_PUpresent = C_new2;
        end
        
    end

end

