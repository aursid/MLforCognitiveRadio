clc
close all
clear all

noOfSignalSamples = 500;   %number of signal samples = omega * tau
trainingDataSize = 500;
testDataSize = 5000;

SUdistances = [707;707;707;707;1581;1581;1581;1581;1581;1581;1581;1581;
               2121;2121;2121;2121;2550;2550;2550;2550;2915;2915;2915;
               2915;3536];  %in metres
                    
PUpower = 0.2;  %in watts
bandwidth = 5e6;    %in hertz
noiseSpectralDensity = -174;    %in dB
noiseSpectralDensity_w = 10 ^ (noiseSpectralDensity/10);   %in watts
tau = 100e-6;

[trainingEnergyVectors, actualPUpresence_training] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, trainingDataSize, SUdistances, noiseSpectralDensity_w);
[testEnergyVectors, actualPUpresence_test] = dataGeneration(tau, noOfSignalSamples, PUpower, bandwidth, testDataSize, SUdistances, noiseSpectralDensity_w);

ratio_euclidean = knn(trainingEnergyVectors, testEnergyVectors', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'euclidean');
ratio_cityblock = knn(trainingEnergyVectors, testEnergyVectors', trainingDataSize, testDataSize, 25, actualPUpresence_training, SUdistances, 'cityblock');

[probOfFalseAlarm_SVM_linear, probOfDetection_SVM_linear] = svm(trainingEnergyVectors, actualPUpresence_training, testEnergyVectors', actualPUpresence_test, 'linear', trainingDataSize, testDataSize);
[probOfFalseAlarm_SVM_polynomial, probOfDetection_SVM_polynomial] = svm_poly(trainingEnergyVectors, actualPUpresence_training, testEnergyVectors', actualPUpresence_test, 'polynomial', trainingDataSize, testDataSize);

[centroid_PUnotPresent, centroid_PUpresent] = kMeansClustering(trainingEnergyVectors, noOfSignalSamples, SUdistances, trainingDataSize);

[vk, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance] = gmm(trainingEnergyVectors, noOfSignalSamples, trainingDataSize, SUdistances);

alpha = linspace(0.5, 2, 1000);
beta = linspace(0, 20, 1000);
gamma = linspace(0, 10, 1000);
for n = 1:numel(beta)
    
    for m = 1:testDataSize
      
        D1_1(m) = pdist([centroid_PUnotPresent'; testEnergyVectors(m,:)]);
        D1_2(m) = pdist([centroid_PUpresent'; testEnergyVectors(m,:)]);

        if (D1_1(m)/D1_2(m) >= alpha(n))
            PredictedState_KmeansClustering(m) = 1;
        else
            PredictedState_KmeansClustering(m) = 0;
        end        

        if (ratio_euclidean(m) >= beta(n))
            PredictedStateKNN_euclidean(m) = 0;
        else
            PredictedStateKNN_euclidean(m) = 1;
        end    

        if (ratio_cityblock(m) >= beta(n))
            PredictedStateKNN_cityblock(m) = 0;
        else
            PredictedStateKNN_cityblock(m) = 1;
        end 
        
        first = vk(1) * phi(testEnergyVectors(m,:)', cluster1mean, cluster1covariance, length(SUdistances));
        second = vk(2) * phi(testEnergyVectors(m,:)', cluster2mean, cluster2covariance, length(SUdistances));
        stat(m) = log(first + second) - log(first);

        if (stat(m) >= gamma(n))
            PredictedStateGMM(m) = 1;
        else
            PredictedStateGMM(m) = 0;
        end        
        
    end

    probOfFalseAlarm_KmeansClustering(n) = sum(PredictedState_KmeansClustering == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KmeansClustering(n) = sum(PredictedState_KmeansClustering == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);    

    probOfFalseAlarm_KNN_euclidean(n) = sum(PredictedStateKNN_euclidean == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_euclidean(n) = sum(PredictedStateKNN_euclidean == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);   

    probOfFalseAlarm_KNN_cityblock(n) = sum(PredictedStateKNN_cityblock == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_KNN_cityblock(n) = sum(PredictedStateKNN_cityblock == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);     

    probOfFalseAlarm_GMM(n) = sum(PredictedStateGMM == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
    probOfDetection_GMM(n) = sum(PredictedStateGMM == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);        
    
end

[probOfFalseAlarm_AND_OR, probOfDetection_AND, probOfDetection_OR] = ANDandOR(SUdistances, testDataSize, testEnergyVectors);
%%
figure;

plot(probOfFalseAlarm_AND_OR, probOfDetection_AND, 'g--', 'LineWidth', 1.5)
hold on
plot(probOfFalseAlarm_AND_OR, probOfDetection_OR, 'k--', 'LineWidth', 1.5)
plot(probOfFalseAlarm_GMM, probOfDetection_GMM, 'r--', 'LineWidth', 1.5)
plot(probOfFalseAlarm_KmeansClustering, probOfDetection_KmeansClustering, 'k', 'LineWidth', 1.5)
plot(probOfFalseAlarm_SVM_linear, probOfDetection_SVM_linear, 'c', 'LineWidth', 1.5)
plot(probOfFalseAlarm_SVM_polynomial, probOfDetection_SVM_polynomial, 'c--', 'LineWidth', 1.5)
plot(probOfFalseAlarm_KNN_euclidean, probOfDetection_KNN_euclidean, 'b', 'LineWidth', 1.5)  
plot(probOfFalseAlarm_KNN_cityblock, probOfDetection_KNN_cityblock, 'b--', 'LineWidth', 1.5)    

legend('AND', 'OR', 'GMM', 'K-Means', 'SVM-Linear', 'SVM-Polynomial', 'KNN-Euclidean', 'KNN-Cityblock')
xlabel('Probability of false alarm')
ylabel('Probability of detection')


