function [ Pf, Pd_AND, Pd_OR ] = ANDandOR( SUdistances, testDataSize, testEnergyVectors )
    %Help for this code was taken from the code to simulate energy
    %detection, written by Sanket Kalamkar (https://uk.mathworks.com/
    %matlabcentral/fileexchange/44569-energy-detection-simulation---
    %cognitive-radio?focused=3802944&tab=function)
    
    Pf = 0:0.01:1;
    for m = 1:length(Pf)
   
        i = 0;
        j = 0;

        Pfa_AND = nthroot(Pf(m), length(SUdistances));
        Pfa_OR = 1 - nthroot(1 - Pf(m), length(SUdistances));

        for kk=1:testDataSize 
            allSUsDetect = 0;
            allSUsDetect_OR = 0;
            for q = 1:length(SUdistances)

                thresh_AND(m) = 63.25 * erfcinv(2*Pfa_AND) + 1000;

                if(testEnergyVectors(kk, q) >= thresh_AND(m))  % Check whether the received energy is greater than threshold, if so, increment Pd (Probability of detection) counter by 1
                    allSUsDetect = allSUsDetect + 1;
                end

                thresh_OR(m) = 63.25 * erfcinv(2*Pfa_OR) + 1000;            

                if(testEnergyVectors(kk, q) >= thresh_OR(m))  % Check whether the received energy is greater than threshold, if so, increment Pd (Probability of detection) counter by 1
                    allSUsDetect_OR = allSUsDetect_OR + 1;
                end            

            end

            if(allSUsDetect == length(SUdistances)) %AND rule
                i = i + 1;
            end  
            if(allSUsDetect_OR > 0) %OR rule
                j = j + 1;
            end

        end

        Pd_AND(m) = i/testDataSize; 
        Pd_OR(m) = j/testDataSize;

    end

end

