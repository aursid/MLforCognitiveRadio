function [ vk, cluster1mean, cluster2mean, cluster1covariance, cluster2covariance ] = gmm( trainingEnergyVectors, noOfSignalSamples, trainingDataSize, SUdistances )

    TrainingDataGMM = trainingEnergyVectors';

    cluster1mean = 2*noOfSignalSamples * ones(length(SUdistances), 1);
    cluster1covariance = 4*noOfSignalSamples * eye(length(SUdistances));
    vk = [0.5; 0.5];
    cluster2mean = TrainingDataGMM(:, trainingDataSize);
    convert2diag = 2000 + rand(length(SUdistances), 1);
    cluster2covariance = diag(convert2diag);

    for k = 1:1000
        for a = 1:trainingDataSize
            phi1 = mvnpdf(TrainingDataGMM(:, a), cluster1mean, cluster1covariance);
            phi2 = mvnpdf(TrainingDataGMM(:, a), cluster2mean, cluster2covariance);

            u1(a) = (vk(1) * phi1)/(vk(1) * phi1 + vk(2) * phi2);
            u2(a) = (vk(2) * phi2)/(vk(1) * phi1 + vk(2) * phi2);
        end

        vk(1) = mean(u1);
        vk(2) = mean(u2);

        cluster2mean = sum(diag(u2') * TrainingDataGMM')/sum(u2);
        cluster2mean = cluster2mean';

        total = zeros(length(SUdistances), length(SUdistances));
        for b = 1:trainingDataSize
            total = total + u2(b) * (diag(TrainingDataGMM(:, b) - cluster2mean))^2;
        end
        cluster2covariance = total/sum(u2);

    end

end


