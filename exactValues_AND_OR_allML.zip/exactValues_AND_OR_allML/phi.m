function [ outputValue ] = phi( energyVector, mu, sigma, N )

    sigmaDet = det(sigma);
    coeff = 1 / (sqrt((2 * pi) ^ N) * sqrt(sigmaDet));
    expon = -0.5 * (energyVector - mu)' * inv(sigma) * (energyVector - mu);
    outputValue = coeff * exp(expon);

end

