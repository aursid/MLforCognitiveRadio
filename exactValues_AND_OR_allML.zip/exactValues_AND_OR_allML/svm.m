function [ probOfFalseAlarm, probOfDetection ] = svm( trainingEnergyVectors, actualPUpresence_training, testEnergyVectors, actualPUpresence_test, kernelFunction, trainingDataSize, testDataSize )

    rng(1);
    SVMModel = fitcsvm(trainingEnergyVectors, actualPUpresence_training', 'Standardize', true, 'KernelFunction', kernelFunction, 'KernelScale', 'auto');

    beta = SVMModel.Beta;
    scale = SVMModel.KernelParameters.Scale;
    
    testEnergyVectors = testEnergyVectors';
    avg = -1 * mean(testEnergyVectors/scale * beta);    
    bias_threshold = -3:0.0001:3;
    bias_threshold = avg * bias_threshold;

    prod = (testEnergyVectors/scale) * beta;
    
    for x = 1:length(bias_threshold)    
        PredictedStates = sign(prod + bias_threshold(x)); 
        PredictedStates(PredictedStates == -1) = 0;

        probOfFalseAlarm(x) = sum(PredictedStates' == 1 & actualPUpresence_test == 0)/sum(actualPUpresence_test == 0);
        probOfDetection(x) = sum(PredictedStates' == 1 & actualPUpresence_test == 1)/sum(actualPUpresence_test == 1);
    end

end

